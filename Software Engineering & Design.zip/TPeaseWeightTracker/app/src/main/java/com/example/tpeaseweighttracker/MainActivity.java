package com.example.tpeaseweighttracker;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class MainActivity extends AppCompatActivity {
    private TextView CurrentTarget;
    private TextView CurrentWeight;
    private TargetWeight targetWeight;
    private DailyWeight dailyWeight;
    private String updateTarget;
    private String updateCurrent;

    AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = Room.databaseBuilder(getApplicationContext(),
            AppDatabase.class, "users").build();
    }

    //creates  class for registering users

    public void RegisterClick(View v){
        EditText usernameText = (EditText) findViewById(R.id.textUsername);
        EditText passwordText = (EditText) findViewById(R.id.textPassword);
        String usernameValue = usernameText.getText().toString();
        String passwordValue = passwordText.getText().toString();
        if(!checkLogin(usernameValue, passwordValue)){
            createUser(usernameValue, passwordValue);
        }
    }

    // checks login information against the database

    private boolean checkLogin(String username, String password){
        UserDao userDao = database.userDao();
        User user = userDao.findByName(username, password);
        return user != null;
    }

    //creates user and inserts into the user DAO

    private void createUser(String username, String password){
        UserDao userDao = database.userDao();
        User user = new User();
        user.userName = username;
        user.password = password;
        userDao.insertAll(user);
    }
}

